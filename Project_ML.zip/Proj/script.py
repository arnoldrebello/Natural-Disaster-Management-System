import numpy as np
import pandas as pd
import os
import datetime
from datetime import date
import json
import urllib.request
from src.fwi import *
from src.final import *
from src.realtime import *
x1 = -7.18
x2 = -6.51
y2 = 41.99
y1 = 41.73
count=0
x = np.arange(x1,x2,0.01)
y = np.arange(y1,y2,0.01)

df = pd.DataFrame(columns=['X', 'Y', 'month', 'day', 'FFMC', 'DMC', 'DC', 'ISI', 'temp', 'RH', 'wind', 'rain'])

count=0

print(df)

for i in x:
    for k in y:
        url = "http://api.openweathermap.org/data/2.5/weather?lat={}&lon={}&appid=fb4dcaed0e642fb68fe48d73b116b7a5".format(i, k)
        j = json.load(urllib.request.urlopen(url))
        dates = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
        now = datetime.datetime.now()
        month = now.month
        day = now.day
        temp = 0
        wind = 0
        rh = 0
        rain = 0
        ffmc = 0
        dmc = 0
        dc = 0
        isi = 0
        lat = i
        long = k
        try:
            temp = j['main']['temp'] - 273.15
        except KeyError:
            pass
        try:
            wind = j['wind']['speed'] * 3.6
        except KeyError:
            pass
        try:
            rh = j['main']['humidity']
        except KeyError:
            pass
        try:
            rain = ((j['rain']['1h']) / 3) / ((742300000 / 9) ** 2)
        except KeyError:
            pass
        try:
            ffmc = FFMC(temp, rh, wind, rain, 57.45)
        except KeyError:
            pass
        try:
            dmc = DMC(temp, rh, rain, 146.2, lat, month)
        except KeyError:
            pass
        try:
            dc = DC(temp, rain, 434.25, lat, month)
        except KeyError:
            pass
        try:
            isi = ISI(wind, ffmc)
        except KeyError:
            pass
        list = {'X': lat,'Y': long,'month': month,'day': day, 'FFMC': ffmc, 'DMC': dmc, 'DC': dc, 'ISI': isi, 'temp': temp, 'RH': rh, 'wind': wind, 'rain': rain}
        df.loc[count] = list
        count+=1
        print("Retrieved {} row(s)".format(count))

today = str(date.today()) 
today = "./database/" + today + ".csv"
    
df.to_csv(today)

print("File saved to database.")

print("Retraining model for newly obtained data.")
retrain_model()

print("Uploading predicted data to Firebase")

upload_to_firebase()
from firebase import firebase
import pandas as pd

firebase = firebase.FirebaseApplication("https://disastermanagement-525b5.firebaseio.com/, None")
result = firebase.delete('/fire_pred','')
print(result)
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import ExtraTreesRegressor
from sklearn.feature_selection import RFE
from datetime import date


import pickle
def retrain_model():
    data = pd.read_csv('./src/train.csv')
    data['month'] = data['month'].map({'feb': 1, 'jan': 0, 'mar': 2, 'apr': 3, 'may': 4, 'jun': 5, 'jul': 6, 'aug': 7, 'sep': 8, 'oct': 9, 'nov': 10, 'dec': 11})
    data['day'] = data['day'].map({'mon': 1, 'sun': 0, 'tue': 2, 'wed': 3, 'thu': 4, 'fri': 5, 'sat': 6})
    used_features = [
        "X",
        "Y",
        "month",
        "day","FFMC","DMC","DC","ISI","temp","RH","wind","rain"
        ]
    features = data[used_features]
    target = data["area"]

    feature_train, feature_test, target_train, target_test = train_test_split(features, target, test_size=0.2, random_state=42)

    reg = ExtraTreesRegressor(n_estimators=100)
    rfe = RFE(reg)
    fit = rfe.fit(feature_train,target_train)

    used_features = ["DMC","temp","RH","wind"]
    features = data[used_features]
    target = data["area"]

    feature_train, feature_test, target_train, target_test = train_test_split(features, target, test_size=0.2, random_state=42)

    reg = ExtraTreesRegressor(n_estimators=100)
    reg.fit(feature_train,target_train)
    reg.score(feature_test,target_test)

    with open('./src/model_pickle','wb') as f:
        pickle.dump(reg,f)
    print("Model updated.")
    
    print("Predicting using new model object.")
    today = str(date.today()) 
    today = "./database/" + today + ".csv"

    test = pd.read_csv(today)
    test_fea = test[used_features]
    resp = reg.predict(test_fea)

    res = [ x / 5 for x in resp]
    print(res)

    test['area'] = res
    test.to_csv("./predicted/output.csv", sep=',',index=False)
    
    print("Predicted data saved to /predicted.")
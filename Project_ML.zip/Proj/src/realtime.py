def upload_to_firebase():
    from firebase import firebase
    import pandas as pd

    firebase = firebase.FirebaseApplication("https://disastermanagement-525b5.firebaseio.com/, None")
    df = pd.read_csv("./predicted/output.csv")
    result = firebase.delete('/fire_pred','')

    for i in df.index:
        X=float(df['X'][i])
        Y=float(df['Y'][i])
        month= str(df['month'][i])
        day= str(df['day'][i])
        FFMC= float(df['FFMC'][i])
        DMC=float(df['DMC'][i])
        DC= float(df['DC'][i])
        ISI= float(df['ISI'][i])
        temp= float(df['temp'][i])
        RH=float(df['RH'][i])
        wind= float(df['wind'][i])
        rain= float(df['rain'][i])
        area= float(df['area'][i])
        
        data = {
            u'X': X,
            u'Y': Y,
            u'month': month,
            u'day': day,
            u'FFMC': FFMC,
            u'DMC': DMC,
            u'DC': DC,
            u'ISI': ISI,
            u'temp': temp,
            u'RH': RH,
            u'wind': wind,
            u'rain': rain,
            u'area': area
        }
        result = firebase.post('/fire_pred',data)
        print("Uploaded {} row(s) to Firebase".format(i))
    print("Upload complete.")